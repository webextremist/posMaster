.LOG
6:02 PM 8/6/2016
admin should be able to add/delete tabs user will have access to. drag and drop configuration
6:04 PM 8/6/2016
should be able to record spoilage or expired products