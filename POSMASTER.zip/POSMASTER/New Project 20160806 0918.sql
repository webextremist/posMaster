-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.6.30-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema posmaster
--

CREATE DATABASE IF NOT EXISTS posmaster;
USE posmaster;

--
-- Definition of table `activitylog`
--

DROP TABLE IF EXISTS `activitylog`;
CREATE TABLE `activitylog` (
  `activitylogID` int(11) NOT NULL AUTO_INCREMENT,
  `staffID` int(11) DEFAULT NULL,
  `activitylogdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `logtype` char(3) NOT NULL,
  PRIMARY KEY (`activitylogID`),
  KEY `activitylog_staffID_fk` (`staffID`),
  CONSTRAINT `activitylog_staffID_fk` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `activitylog`
--

/*!40000 ALTER TABLE `activitylog` DISABLE KEYS */;
/*!40000 ALTER TABLE `activitylog` ENABLE KEYS */;


--
-- Definition of table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `Address_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Line_1` varchar(45) NOT NULL,
  `Line_2` varchar(45) NOT NULL,
  `Line_3` varchar(45) NOT NULL,
  `City` varchar(45) NOT NULL,
  `Zip_Code` varchar(45) NOT NULL,
  `District_ID` int(11) DEFAULT NULL,
  `LoginUser` varchar(45) NOT NULL,
  PRIMARY KEY (`Address_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;


--
-- Definition of table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `categoryID` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(250) NOT NULL,
  `LoginUSer` varchar(45) DEFAULT NULL,
  `chkStatus` char(1) NOT NULL,
  `captureDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`categoryID`),
  UNIQUE KEY `categoryname` (`categoryname`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`categoryID`,`categoryname`,`LoginUSer`,`chkStatus`,`captureDate`) VALUES 
 (44,'BABY PRODUCTS','kaunda','1','2016-08-05 10:18:47'),
 (48,'ELECTRNONICS','kaunda','1','2016-08-05 10:18:47'),
 (49,'SOFTWARE','kaunda','1','2016-08-05 10:18:47'),
 (50,'DRINKS','kaunda','1','2016-08-05 10:18:47'),
 (51,'FRUITS AND VEGETABLES','kaunda','1','2016-08-05 10:18:47'),
 (52,'PAPER GOODS','kaunda','1','2016-08-05 10:18:47'),
 (53,'BEVERAGES','kaunda','1','2016-08-05 11:44:21'),
 (54,'CABLES','kaunda','1','2016-08-05 12:27:45'),
 (55,'SCREEN','kaunda','1','2016-08-05 12:33:53'),
 (56,'WEB CONSULTANCY','kaunda','1','2016-08-06 18:37:34'),
 (57,'SMARTPHONE','kaunda','1','2016-08-06 19:32:29'),
 (58,'HUMAN BEING','kaunda','1','2016-08-07 05:56:12'),
 (59,'RADIO STATIONS','kaunda','1','2016-08-07 06:00:08'),
 (60,'PLANTS','kaunda','1','2016-08-07 06:01:33'),
 (61,'TEACHERS','kaunda','1','2016-08-07 06:04:30');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Definition of table `country`
--

DROP TABLE IF EXISTS `country`;
CREATE TABLE `country` (
  `Country_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Country_Name` varchar(250) NOT NULL,
  `Country_Code` varchar(45) NOT NULL,
  `Country_Currency` varchar(45) NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Country_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `country`
--

/*!40000 ALTER TABLE `country` DISABLE KEYS */;
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `Customer_ID` varchar(45) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `othername` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `Titleid` tinyint(4) DEFAULT NULL,
  `District_ID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`Customer_ID`),
  KEY `fkey_customer_title` (`Titleid`),
  KEY `FK_customer_District` (`District_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `customer_order`
--

DROP TABLE IF EXISTS `customer_order`;
CREATE TABLE `customer_order` (
  `Customer_Order_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Customer_ID` varchar(45) NOT NULL,
  `Stock_ID` int(10) unsigned NOT NULL,
  `Quantity` decimal(10,0) NOT NULL,
  `OrderDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LoginUser` varchar(45) NOT NULL,
  `Order_Status_ID` int(10) unsigned NOT NULL,
  `payment_Type_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Customer_Order_ID`),
  KEY `FK_CustomerOrder_Customer` (`Customer_ID`),
  KEY `FK_CustomerOrder_Stock` (`Stock_ID`),
  KEY `FK_CustomerOrder_OrderStatus` (`Order_Status_ID`),
  KEY `FK_CustomerOrder_PaymentType` (`payment_Type_ID`),
  CONSTRAINT `FK_CustomerOrder_Customer` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`),
  CONSTRAINT `FK_CustomerOrder_OrderStatus` FOREIGN KEY (`Order_Status_ID`) REFERENCES `order_status` (`Order_Status_ID`),
  CONSTRAINT `FK_CustomerOrder_PaymentType` FOREIGN KEY (`payment_Type_ID`) REFERENCES `payment_type` (`Payment_Type_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_order`
--

/*!40000 ALTER TABLE `customer_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_order` ENABLE KEYS */;


--
-- Definition of table `customer_title`
--

DROP TABLE IF EXISTS `customer_title`;
CREATE TABLE `customer_title` (
  `titleid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `title_desc` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`titleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_title`
--

/*!40000 ALTER TABLE `customer_title` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_title` ENABLE KEYS */;


--
-- Definition of table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE `delivery` (
  `Delivery_ID` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `Delivery_Date` date NOT NULL,
  `Expected_Delivery_Date` date DEFAULT NULL,
  `Delivery_Category_ID` int(10) unsigned NOT NULL COMMENT 'Customer or Supplier or any other ',
  `LoginUser` varchar(45) NOT NULL,
  PRIMARY KEY (`Delivery_ID`) USING BTREE,
  KEY `FK_delivery_DeliveryCategory` (`Delivery_Category_ID`),
  CONSTRAINT `FK_delivery_DeliveryCategory` FOREIGN KEY (`Delivery_Category_ID`) REFERENCES `delivery_category` (`Delivery_Category_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `delivery`
--

/*!40000 ALTER TABLE `delivery` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery` ENABLE KEYS */;


--
-- Definition of table `delivery_category`
--

DROP TABLE IF EXISTS `delivery_category`;
CREATE TABLE `delivery_category` (
  `Delivery_Category_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Category` varchar(45) NOT NULL,
  PRIMARY KEY (`Delivery_Category_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Deliverying to customer or Supplier delivery to you';

--
-- Dumping data for table `delivery_category`
--

/*!40000 ALTER TABLE `delivery_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `delivery_category` ENABLE KEYS */;


--
-- Definition of table `district`
--

DROP TABLE IF EXISTS `district`;
CREATE TABLE `district` (
  `District_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `District_Name` varchar(250) NOT NULL,
  `District_Code` varchar(45) NOT NULL,
  `Region_ID` int(10) unsigned NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`District_ID`),
  KEY `FK_district_Region` (`Region_ID`),
  CONSTRAINT `FK_district_Region` FOREIGN KEY (`Region_ID`) REFERENCES `region` (`Region_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `district`
--

/*!40000 ALTER TABLE `district` DISABLE KEYS */;
/*!40000 ALTER TABLE `district` ENABLE KEYS */;


--
-- Definition of table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `expenses_category_ID` int(10) unsigned NOT NULL,
  `expense_description` varchar(250) NOT NULL,
  `expense_amount` decimal(18,2) NOT NULL,
  `date_captured` datetime DEFAULT NULL,
  `staffid` varchar(20) NOT NULL,
  PRIMARY KEY (`expense_id`) USING BTREE,
  KEY `FK_expenses_expenses_category` (`expenses_category_ID`),
  CONSTRAINT `FK_expenses_expenses_category` FOREIGN KEY (`expenses_category_ID`) REFERENCES `expenses_category` (`expenses_category_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `expenses`
--

/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;


--
-- Definition of table `expenses_category`
--

DROP TABLE IF EXISTS `expenses_category`;
CREATE TABLE `expenses_category` (
  `expenses_category_ID` int(10) unsigned NOT NULL,
  `cat_description` varchar(250) DEFAULT NULL,
  `cat_date` datetime DEFAULT NULL,
  PRIMARY KEY (`expenses_category_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `expenses_category`
--

/*!40000 ALTER TABLE `expenses_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_category` ENABLE KEYS */;


--
-- Definition of table `fill_combobox_with_numbers`
--

DROP TABLE IF EXISTS `fill_combobox_with_numbers`;
CREATE TABLE `fill_combobox_with_numbers` (
  `numbers` int(11) DEFAULT NULL,
  UNIQUE KEY `numbers` (`numbers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fill_combobox_with_numbers`
--

/*!40000 ALTER TABLE `fill_combobox_with_numbers` DISABLE KEYS */;
INSERT INTO `fill_combobox_with_numbers` (`numbers`) VALUES 
 (1),
 (2),
 (3),
 (4),
 (5),
 (6),
 (7),
 (8),
 (9),
 (10),
 (11),
 (12),
 (13),
 (14),
 (15),
 (16),
 (17),
 (18),
 (19),
 (20),
 (21),
 (22),
 (23),
 (24),
 (25),
 (26),
 (27),
 (28),
 (29),
 (30);
/*!40000 ALTER TABLE `fill_combobox_with_numbers` ENABLE KEYS */;


--
-- Definition of table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE `item` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `itemname` varchar(150) NOT NULL,
  `categoryID` int(11) DEFAULT NULL,
  `chkStatus` char(1) DEFAULT '1',
  `capturedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `loginUser` varchar(45) NOT NULL,
  PRIMARY KEY (`itemID`),
  KEY `item_categoryID_fk` (`categoryID`),
  CONSTRAINT `item_categoryID_fk` FOREIGN KEY (`categoryID`) REFERENCES `category` (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` (`itemID`,`itemname`,`categoryID`,`chkStatus`,`capturedate`,`loginUser`) VALUES 
 (92,'PEN DRIVE',48,NULL,'2016-08-05 11:57:50','kaunda'),
 (93,'COMPACT DISK (CD)',48,'1','2016-08-05 12:09:45','kaunda'),
 (94,'MICROSOFT OFFICE SUITE',49,'1','2016-08-05 12:10:11','kaunda'),
 (95,'ADOBE SUITE CS6 ULTIMATE',49,'1','2016-08-05 12:10:32','kaunda'),
 (96,'CAT 5',54,'1','2016-08-05 12:33:42','kaunda'),
 (97,'LED LIGHT',55,'1','2016-08-05 12:34:21','kaunda'),
 (98,'SEARCH ENGINE OPTIMIZATION (SEO)',56,'1','2016-08-06 18:38:07','kaunda'),
 (99,'PAYMASTER',49,'1','2016-08-06 19:25:57','kaunda'),
 (100,'COLA',50,'1','2016-08-06 19:26:13','kaunda'),
 (101,'MALT',50,'1','2016-08-06 19:26:27','kaunda'),
 (102,'RUSH',50,'1','2016-08-06 19:26:36','kaunda'),
 (103,'AVARO',50,'1','2016-08-06 19:26:44','kaunda'),
 (104,'TOMATO',51,'1','2016-08-06 19:26:54','kaunda'),
 (105,'ONION',51,'1','2016-08-06 19:26:59','kaunda'),
 (106,'OKRA',51,'1','2016-08-06 19:27:08','kaunda'),
 (107,'WATER MILO',51,'1','2016-08-06 19:27:20','kaunda'),
 (108,'CLIPPERS',52,'1','2016-08-06 19:27:55','kaunda'),
 (109,'A4 PAPPERS',52,'1','2016-08-06 19:28:06','kaunda'),
 (110,'DRAWING BOARD',52,'1','2016-08-06 19:28:19','kaunda'),
 (111,'CAT 5 E',54,'1','2016-08-06 19:28:51','kaunda'),
 (112,'CAT 5E',54,'1','2016-08-06 19:28:58','kaunda'),
 (113,'17\'\' LABTOP',55,'1','2016-08-06 19:29:35','kaunda'),
 (114,'LED MONITOR HP',55,'1','2016-08-06 19:29:52','kaunda'),
 (115,'HARD DISK',48,'1','2016-08-06 19:31:40','kaunda'),
 (116,'MEMORY',48,'1','2016-08-06 19:31:48','kaunda'),
 (117,'BATTERY',48,'1','2016-08-06 19:31:53','kaunda'),
 (118,'CHARGER',48,'1','2016-08-06 19:31:59','kaunda'),
 (119,'IPHONE 6',57,'1','2016-08-06 19:33:07','kaunda'),
 (120,'SAMSUNG',57,'1','2016-08-06 19:33:23','kaunda'),
 (121,'HTC',57,'1','2016-08-06 19:33:28','kaunda'),
 (122,'NOKIA',57,'1','2016-08-06 19:33:32','kaunda'),
 (123,'INFINIX',57,'1','2016-08-06 19:33:40','kaunda'),
 (124,'RESPONSIVE WEB DESIGN',56,'1','2016-08-06 19:35:52','kaunda'),
 (125,'BEST PRACTICE IN CSS',56,'1','2016-08-06 19:36:04','kaunda'),
 (126,'PITO',53,'1','2016-08-06 19:36:19','kaunda'),
 (127,'DOKA',53,'1','2016-08-06 19:36:32','kaunda'),
 (128,'DUNKU',53,'1','2016-08-06 19:37:03','kaunda'),
 (129,'SHIRT',44,'1','2016-08-06 19:37:48','kaunda'),
 (130,'PAMP3S',44,'1','2016-08-06 19:37:55','kaunda'),
 (131,'DIPERS',44,'1','2016-08-06 19:38:09','kaunda'),
 (132,'VISUAL STUDIO 2015 ULTIMATE',49,'1','2016-08-07 05:48:07','kaunda'),
 (133,'CASSAVA',60,'1','2016-08-07 06:01:58','kaunda'),
 (134,'NATIONAL SERVICE PERSONNEL',61,'1','2016-08-07 06:05:03','kaunda');
/*!40000 ALTER TABLE `item` ENABLE KEYS */;


--
-- Definition of table `itemdetails`
--

DROP TABLE IF EXISTS `itemdetails`;
CREATE TABLE `itemdetails` (
  `itemdetailsID` int(11) NOT NULL AUTO_INCREMENT,
  `itemID` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unitprice` decimal(10,2) NOT NULL,
  `datecaptured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `itemdetails_Status` char(1) DEFAULT NULL,
  PRIMARY KEY (`itemdetailsID`),
  KEY `itemdetails_itemID_fk` (`itemID`),
  CONSTRAINT `itemdetails_itemID_fk` FOREIGN KEY (`itemID`) REFERENCES `item` (`itemID`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `itemdetails`
--

/*!40000 ALTER TABLE `itemdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `itemdetails` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(75) NOT NULL,
  `userpassword` varchar(200) NOT NULL,
  `staffID` int(11) DEFAULT NULL,
  `userlevelID` int(11) DEFAULT NULL,
  PRIMARY KEY (`userID`),
  KEY `login_staffID_fk` (`staffID`),
  KEY `login_userlevelID_fk` (`userlevelID`),
  CONSTRAINT `login_staffID_fk` FOREIGN KEY (`staffID`) REFERENCES `staff` (`staffID`),
  CONSTRAINT `login_userlevelID_fk` FOREIGN KEY (`userlevelID`) REFERENCES `userlevel` (`userlevelID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`userID`,`username`,`userpassword`,`staffID`,`userlevelID`) VALUES 
 (2,'kaunda','891dfc09e74650f26cdeb10b3be8a8c9add59e2f',1,1),
 (3,'manager','1a8565a9dc72048ba03b4156be3e569f22771f23',3,3),
 (4,'sales','59248c4dae276a021cb296d2ee0e6a0c962a8d7f',4,2),
 (5,'error','11f9578d05e6f7bb58a3cdd00107e9f4e3882671',14,2);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `make`
--

DROP TABLE IF EXISTS `make`;
CREATE TABLE `make` (
  `MakeID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Make` varchar(250) NOT NULL,
  `captureDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LoginUser` varchar(45) NOT NULL,
  PRIMARY KEY (`MakeID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `make`
--

/*!40000 ALTER TABLE `make` DISABLE KEYS */;
INSERT INTO `make` (`MakeID`,`Make`,`captureDate`,`LoginUser`) VALUES 
 (2,'BoomSol Software Services','2016-08-06 17:52:26','kaunda'),
 (3,'SYNC GHANA','2016-08-06 17:54:05','kaunda'),
 (4,'WEB EXTREMIST','2016-08-06 17:54:45','kaunda'),
 (5,'DIGITAL COMPANION','2016-08-06 17:54:58','kaunda');
/*!40000 ALTER TABLE `make` ENABLE KEYS */;


--
-- Definition of table `order_status`
--

DROP TABLE IF EXISTS `order_status`;
CREATE TABLE `order_status` (
  `Order_Status_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Order_Status` varchar(45) NOT NULL,
  PRIMARY KEY (`Order_Status_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_status`
--

/*!40000 ALTER TABLE `order_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_status` ENABLE KEYS */;


--
-- Definition of table `orderpayment`
--

DROP TABLE IF EXISTS `orderpayment`;
CREATE TABLE `orderpayment` (
  `orderpaymentid` int(11) NOT NULL AUTO_INCREMENT,
  `orderitemID` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `paymenttypeid` int(11) DEFAULT NULL,
  `NextpaymentTime` date DEFAULT NULL,
  `capturedate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`orderpaymentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderpayment`
--

/*!40000 ALTER TABLE `orderpayment` DISABLE KEYS */;
INSERT INTO `orderpayment` (`orderpaymentid`,`orderitemID`,`amount`,`paymenttypeid`,`NextpaymentTime`,`capturedate`) VALUES 
 (1,57,'200.00',2,'2016-02-02','2016-01-16 16:00:00');
/*!40000 ALTER TABLE `orderpayment` ENABLE KEYS */;


--
-- Definition of table `payment_type`
--

DROP TABLE IF EXISTS `payment_type`;
CREATE TABLE `payment_type` (
  `Payment_Type_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Payment_Type` varchar(45) NOT NULL COMMENT 'Part payment, full, or nothing at all',
  PRIMARY KEY (`Payment_Type_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_type`
--

/*!40000 ALTER TABLE `payment_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_type` ENABLE KEYS */;


--
-- Definition of table `paymenttype`
--

DROP TABLE IF EXISTS `paymenttype`;
CREATE TABLE `paymenttype` (
  `paymenttypeid` int(11) NOT NULL AUTO_INCREMENT,
  `paymenttype` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`paymenttypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `paymenttype`
--

/*!40000 ALTER TABLE `paymenttype` DISABLE KEYS */;
INSERT INTO `paymenttype` (`paymenttypeid`,`paymenttype`) VALUES 
 (1,'Full Payment'),
 (2,'Part Payment'),
 (3,'No Payment');
/*!40000 ALTER TABLE `paymenttype` ENABLE KEYS */;


--
-- Definition of table `region`
--

DROP TABLE IF EXISTS `region`;
CREATE TABLE `region` (
  `Region_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Region_Name` varchar(250) NOT NULL,
  `Region_Code` varchar(45) NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Country_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Region_ID`),
  KEY `FK_region_Country` (`Country_ID`),
  CONSTRAINT `FK_region_Country` FOREIGN KEY (`Country_ID`) REFERENCES `country` (`Country_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `region`
--

/*!40000 ALTER TABLE `region` DISABLE KEYS */;
/*!40000 ALTER TABLE `region` ENABLE KEYS */;


--
-- Definition of table `shopping_cart`
--

DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE `shopping_cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(250) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `UnitCost` decimal(18,2) DEFAULT NULL,
  `staffid` varchar(20) DEFAULT NULL,
  `date_captured` datetime DEFAULT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shopping_cart`
--

/*!40000 ALTER TABLE `shopping_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `shopping_cart` ENABLE KEYS */;


--
-- Definition of table `social_media`
--

DROP TABLE IF EXISTS `social_media`;
CREATE TABLE `social_media` (
  `Social_Media_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Social_Media_Name` varchar(45) NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`Social_Media_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `social_media`
--

/*!40000 ALTER TABLE `social_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_media` ENABLE KEYS */;


--
-- Definition of table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `staffID` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(120) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `staff`
--

/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` (`staffID`,`firstname`,`lastname`,`phone`) VALUES 
 (1,'first','lastname','234567'),
 (2,'first','lastname','234567'),
 (3,'Manager','Francis','1111111'),
 (4,'Sales','Fremah','2222222222'),
 (5,'Danis','Darko','0000000000'),
 (6,'Kumi','Francis','1111111111'),
 (7,'Ama','Yaa','2222222222'),
 (8,'adu','kwame','3333333333'),
 (9,'Amadu','Salifu','4444444444'),
 (10,'ss','sss','ss'),
 (11,'good','good','5555555555'),
 (12,'kk','kk','kk'),
 (14,'danso','siaw','88888888');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;


--
-- Definition of table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock` (
  `StockID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `itemID` int(11) NOT NULL DEFAULT '0',
  `quantity` int(11) DEFAULT NULL,
  `UnitPrice` decimal(18,2) NOT NULL,
  `mfgDate` date DEFAULT NULL,
  `expDate` date NOT NULL DEFAULT '0000-00-00',
  `captureDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `BatchNO` varchar(45) DEFAULT NULL,
  `stockstatus` char(1) DEFAULT '1',
  `LoginUser` varchar(45) NOT NULL,
  `MakeID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`StockID`),
  KEY `FK_stock_Make` (`MakeID`),
  KEY `FK_stock_Item` (`itemID`),
  CONSTRAINT `FK_stock_Item` FOREIGN KEY (`itemID`) REFERENCES `item` (`itemID`),
  CONSTRAINT `FK_stock_Make` FOREIGN KEY (`MakeID`) REFERENCES `make` (`MakeID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='contains lilst of items';

--
-- Dumping data for table `stock`
--

/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` (`StockID`,`itemID`,`quantity`,`UnitPrice`,`mfgDate`,`expDate`,`captureDate`,`BatchNO`,`stockstatus`,`LoginUser`,`MakeID`) VALUES 
 (1,93,500,'0.00','2016-08-06','2016-08-06','2016-08-06 18:35:58','KO454545V','1','kaunda',2),
 (2,94,500,'0.00','2014-03-06','2020-08-06','2016-08-06 18:37:12','DFGD545V00','1','kaunda',4),
 (3,98,45,'0.00','2015-11-06','2020-08-06','2016-08-06 18:38:45','','1','kaunda',3),
 (4,96,411,'0.00','2016-08-06','2016-08-06','2016-08-06 18:46:11','','1','kaunda',2),
 (5,97,300,'0.00','2016-08-06','2016-08-06','2016-08-06 18:46:25','','2','kaunda',2),
 (6,95,10,'0.00','2016-08-06','2016-08-06','2016-08-06 18:46:39','','0','kaunda',5),
 (7,93,10000,'0.00','2016-08-06','2016-08-06','2016-08-06 18:46:59','','1','kaunda',5),
 (8,108,1000,'0.00','2016-08-06','2016-08-06','2016-08-06 19:30:38','GG4545DF','0','kaunda',5),
 (9,120,555,'0.00','2016-08-06','2016-08-06','2016-08-06 19:34:21','KJ45744G','1','kaunda',4),
 (10,121,74,'0.00','2016-08-06','2016-08-06','2016-08-06 19:34:37','KJ45744G','1','kaunda',4),
 (11,123,300,'0.00','2016-08-06','2016-08-06','2016-08-06 19:34:57','GDDD255V','1','kaunda',4),
 (12,132,100,'0.00','2015-08-07','2020-08-07','2016-08-07 05:48:57','KDDGD2000','1','kaunda',2),
 (13,126,100,'0.00','2015-08-07','2020-08-07','2016-08-07 05:51:52','DFGHJ2521','1','kaunda',5),
 (14,100,100,'0.00','2015-08-07','2020-08-07','2016-08-07 05:53:30','YTG2242121','1','kaunda',5),
 (15,134,100,'0.00','2014-02-07','2013-08-07','2016-08-07 06:06:04','ERE2222','1','kaunda',5),
 (16,134,100,'0.00','2014-02-07','2013-08-07','2016-08-07 06:09:39','ERE2222','1','kaunda',5);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;


--
-- Definition of table `stock_category`
--

DROP TABLE IF EXISTS `stock_category`;
CREATE TABLE `stock_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(250) DEFAULT NULL,
  `date_captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LoginUser` varchar(45) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock_category`
--

/*!40000 ALTER TABLE `stock_category` DISABLE KEYS */;
INSERT INTO `stock_category` (`category_id`,`description`,`date_captured`,`LoginUser`) VALUES 
 (1,'ITALIAN','2016-05-04 16:00:00','kaunda'),
 (2,'UK','2015-09-08 16:00:00','khan'),
 (3,'US','2010-12-11 16:00:00','jinjiwa');
/*!40000 ALTER TABLE `stock_category` ENABLE KEYS */;


--
-- Definition of table `stock_supplier`
--

DROP TABLE IF EXISTS `stock_supplier`;
CREATE TABLE `stock_supplier` (
  `Stock_SupplierID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Stock_ID` int(10) unsigned NOT NULL,
  `Supplier_ID` int(10) unsigned NOT NULL,
  `Stock_Unit_Price` decimal(18,2) NOT NULL,
  `Stock_Percentage_Discount` decimal(18,2) NOT NULL,
  `Stock_Quantity` decimal(18,2) NOT NULL,
  `Stock_Delivery_Date` date NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Stock_Next_Supply_Date` date NOT NULL,
  `SuppliedBy` varchar(45) NOT NULL,
  PRIMARY KEY (`Stock_SupplierID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock_supplier`
--

/*!40000 ALTER TABLE `stock_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_supplier` ENABLE KEYS */;


--
-- Definition of table `stockentrystatus`
--

DROP TABLE IF EXISTS `stockentrystatus`;
CREATE TABLE `stockentrystatus` (
  `StockEntryStatusID` int(11) NOT NULL AUTO_INCREMENT,
  `StockEntryStatus` char(1) DEFAULT NULL,
  `StockEntryStatusDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`StockEntryStatusID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stockentrystatus`
--

/*!40000 ALTER TABLE `stockentrystatus` DISABLE KEYS */;
INSERT INTO `stockentrystatus` (`StockEntryStatusID`,`StockEntryStatus`,`StockEntryStatusDate`) VALUES 
 (1,'1','2015-12-13 07:02:04'),
 (2,'0','2015-12-13 07:07:25'),
 (3,'1','2015-12-13 07:12:22'),
 (4,'0','2015-12-13 07:25:35'),
 (5,'1','2015-12-13 07:29:21'),
 (6,'0','2015-12-13 07:34:58'),
 (7,'0','2015-12-13 07:35:21'),
 (8,'0','2015-12-13 07:35:28'),
 (9,'0','2015-12-13 07:35:50'),
 (10,'1','2015-12-13 07:39:42'),
 (11,'0','2015-12-13 07:40:02'),
 (12,'1','2015-12-13 10:38:24'),
 (13,'0','2015-12-18 01:15:16'),
 (14,'1','2015-12-18 01:17:35'),
 (15,'0','2015-12-27 05:48:57'),
 (16,'1','2015-12-27 05:49:15'),
 (17,'0','2016-01-03 02:47:38'),
 (18,'1','2016-01-03 02:47:41'),
 (19,'0','2016-01-03 02:48:52'),
 (20,'1','2016-01-03 02:48:55'),
 (21,'0','2016-01-03 02:49:48'),
 (22,'1','2016-01-03 02:49:52'),
 (23,'0','2016-01-03 02:49:53'),
 (24,'1','2016-01-03 02:50:49'),
 (25,'0','2016-01-03 04:15:53'),
 (26,'1','2016-01-03 04:59:22'),
 (27,'0','2016-01-03 05:42:29'),
 (28,'1','2016-01-03 05:42:35'),
 (29,'0','2016-01-16 23:42:35'),
 (30,'1','2016-01-16 23:42:45'),
 (31,'0','2016-01-16 23:42:49'),
 (32,'1','2016-01-17 00:25:34'),
 (33,'0','2016-01-17 00:27:30');
/*!40000 ALTER TABLE `stockentrystatus` ENABLE KEYS */;


--
-- Definition of table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `supplier_ID` varchar(20) NOT NULL,
  `Supplier_name` varchar(250) NOT NULL,
  `supplier_Phone` varchar(20) DEFAULT NULL,
  `Supplier_Email` varchar(45) DEFAULT NULL,
  `Supplier_Website` varchar(45) NOT NULL,
  `Supplier_Currency` varchar(45) NOT NULL,
  `Supplier_VAT_Status` varchar(45) NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `District_ID` int(10) unsigned NOT NULL,
  PRIMARY KEY (`supplier_ID`),
  KEY `FK_supplier_District` (`District_ID`),
  CONSTRAINT `FK_supplier_District` FOREIGN KEY (`District_ID`) REFERENCES `district` (`District_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier`
--

/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;


--
-- Definition of table `supplier_payment_term`
--

DROP TABLE IF EXISTS `supplier_payment_term`;
CREATE TABLE `supplier_payment_term` (
  `SPT_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Supplier_ID` int(11) NOT NULL,
  `SPT_Description` varchar(250) NOT NULL,
  PRIMARY KEY (`SPT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier_payment_term`
--

/*!40000 ALTER TABLE `supplier_payment_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_payment_term` ENABLE KEYS */;


--
-- Definition of table `supplier_social_media`
--

DROP TABLE IF EXISTS `supplier_social_media`;
CREATE TABLE `supplier_social_media` (
  `SSM_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Social_Media_id` int(10) unsigned NOT NULL,
  `Supplier_ID` varchar(20) NOT NULL,
  `Media_Handle` varchar(250) NOT NULL,
  `Date_Captured` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`SSM_ID`),
  KEY `FK_supplier_social_media_1` (`Supplier_ID`),
  KEY `FK_supplier_social_media_2` (`Social_Media_id`),
  CONSTRAINT `FK_supplier_social_media_1` FOREIGN KEY (`Supplier_ID`) REFERENCES `supplier` (`supplier_ID`),
  CONSTRAINT `FK_supplier_social_media_2` FOREIGN KEY (`Social_Media_id`) REFERENCES `social_media` (`Social_Media_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supplier_social_media`
--

/*!40000 ALTER TABLE `supplier_social_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_social_media` ENABLE KEYS */;


--
-- Definition of table `switch`
--

DROP TABLE IF EXISTS `switch`;
CREATE TABLE `switch` (
  `switchcode` char(1) DEFAULT NULL,
  `switchDesc` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `switch`
--

/*!40000 ALTER TABLE `switch` DISABLE KEYS */;
INSERT INTO `switch` (`switchcode`,`switchDesc`) VALUES 
 ('0','Close Stock'),
 ('1','Open Stock');
/*!40000 ALTER TABLE `switch` ENABLE KEYS */;


--
-- Definition of table `temporderitems`
--

DROP TABLE IF EXISTS `temporderitems`;
CREATE TABLE `temporderitems` (
  `tempItemID` int(11) DEFAULT NULL,
  `tempItemName` varchar(250) DEFAULT NULL,
  `tempQuantity` int(11) DEFAULT NULL,
  `UnitCost` decimal(18,2) DEFAULT NULL,
  `staffID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `temporderitems`
--

/*!40000 ALTER TABLE `temporderitems` DISABLE KEYS */;
INSERT INTO `temporderitems` (`tempItemID`,`tempItemName`,`tempQuantity`,`UnitCost`,`staffID`) VALUES 
 (5,'SUGAR BREAD',11,'9.00',1),
 (5,'SUGAR BREAD',11,'9.00',1),
 (9,'UNCLE SAM',44,'375.00',1),
 (9,'UNCLE SAM',44,'375.00',1);
/*!40000 ALTER TABLE `temporderitems` ENABLE KEYS */;


--
-- Definition of table `title`
--

DROP TABLE IF EXISTS `title`;
CREATE TABLE `title` (
  `Title_ID` int(11) NOT NULL DEFAULT '0',
  `Title` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`Title_ID`),
  UNIQUE KEY `uniq_Title` (`Title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `title`
--

/*!40000 ALTER TABLE `title` DISABLE KEYS */;
INSERT INTO `title` (`Title_ID`,`Title`) VALUES 
 (0,'Mr.');
/*!40000 ALTER TABLE `title` ENABLE KEYS */;


--
-- Definition of table `userlevel`
--

DROP TABLE IF EXISTS `userlevel`;
CREATE TABLE `userlevel` (
  `userlevelID` int(11) NOT NULL AUTO_INCREMENT,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`userlevelID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `userlevel`
--

/*!40000 ALTER TABLE `userlevel` DISABLE KEYS */;
INSERT INTO `userlevel` (`userlevelID`,`usertype`) VALUES 
 (1,'Admin'),
 (2,'Sales Person'),
 (3,'Manager');
/*!40000 ALTER TABLE `userlevel` ENABLE KEYS */;


--
-- Definition of procedure `AddCategory`
--

DROP PROCEDURE IF EXISTS `AddCategory`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddCategory`(
IN paraCategoryName varchar(250)
,IN paraLoginUser varchar(32)
)
begin

insert into category
(categoryname,loginuser,chkstatus)
values
(
paraCategoryName
,paraLoginUser
,'1'
);
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `AddItem`
--

DROP PROCEDURE IF EXISTS `AddItem`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `AddItem`(
 in paraItemName varchar(250)
,in paraCategoryID int
,in paraloginuser varchar(32)
)
begin

insert into item
(
      itemname
      ,categoryid
      ,loginuser
)

values
(
       paraItemName
      ,paraCategoryID
      ,paraloginuser
);
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `AddMake`
--

DROP PROCEDURE IF EXISTS `AddMake`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`khan`@`localhost` PROCEDURE `AddMake`(
    paraMake varchar(250)
  , paraloginUser varchar(32)
)
begin

insert into make
(
Make
,loginuser
)
values
(
ucase(paraMake )
,lcase(paraloginUser)
);
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `AddStock`
--

DROP PROCEDURE IF EXISTS `AddStock`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`khan`@`localhost` PROCEDURE `AddStock`(
          IN paraItemID int
 ,       IN paraQuantity int
 ,       IN paraUnitPrice decimal(18,2)
 ,       IN paraMakerID   int
 ,       IN paraMfgDate date
 ,       IN paraExpDate date
 ,       IN paraBatchNo varchar(50)
 #,       IN paraStatus char(1)
 ,       IN paraLoginUser varchar(50)
)
BEGIN

       INSERT INTO STOCK
(
                   itemid
,                  quantity
,                  unitprice
,                  makeid
,                  mfgDate
,                  expDate
,                  capturedate
,                  batchno
#,                  stockstatus
,                  loginUser
)

VALUES

(

          paraItemID
,         paraQuantity
,         paraUnitPrice
,         paraMakerID
,         paraMfgDate       #STR_TO_DATE(paraMfgDate,'%m-%d-%Y')
,         paraExpDate       #STR_TO_DATE(paraExpDate ,'%m-%d-%Y')
,         current_time
,         ucase(paraBatchNo)
#,         paraStatus
,         paraLoginUser


) ;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `getCategory`
--

DROP PROCEDURE IF EXISTS `getCategory`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getCategory`(
in  prostatus char(1)

)
begin
SELECT categoryid,categoryname FROM category where chkstatus=prostatus order by capturedate desc;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `getItemByCategoryID`
--

DROP PROCEDURE IF EXISTS `getItemByCategoryID`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`khan`@`localhost` PROCEDURE `getItemByCategoryID`(
       paraCategoryID int
)
BEGIN
    select itemid,itemname
from item
where chkstatus='1'
and categoryid=paraCategoryID
order by capturedate desc;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `getItemMake`
--

DROP PROCEDURE IF EXISTS `getItemMake`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`khan`@`localhost` PROCEDURE `getItemMake`(
parachkStaatu char(1) # im not useing this parameter though. will use it in future maybe
)
begin



select makeid,make from make;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `getItems`
--

DROP PROCEDURE IF EXISTS `getItems`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `getItems`(
in parachkStatus char(1)
)
begin




select itemid,itemname,categoryid
from item
where chkstatus=parachkStatus

order by capturedate desc;


end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `getItemsStock`
--

DROP PROCEDURE IF EXISTS `getItemsStock`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ $$
CREATE DEFINER=`khan`@`localhost` PROCEDURE `getItemsStock`(
paraCategoryID int #will be used later. will put in 1. as placeHolder in code. supposed to be used in WHERE condition
)
begin

select stockid
,categoryid
,i.itemid
,itemname   as NAME
,QUANTITY
,UNITPRICE
,date_format(mfgdate,'%d %b %Y' )  as mfgDATE
,date_format(expdate,'%d %b %Y' )  as expDATE
,BATCHNO
,
 case stockstatus
 when 1 then 'Active'
 when 0 then 'Expire'
 else 'unknown'
 end as 'Status'
from stock s inner join item i
on s.itemid=i.itemid

WHERE Categoryid = paraCategoryID
order by s.capturedate desc;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
