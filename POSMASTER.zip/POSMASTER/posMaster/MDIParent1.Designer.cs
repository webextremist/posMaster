﻿namespace Kaunda
{
    partial class MDIParent1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIParent1));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.tabSales = new MetroFramework.Controls.MetroTabPage();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.tabItems = new System.Windows.Forms.TabPage();
            this.tabCustomers = new MetroFramework.Controls.MetroTabPage();
            this.tabSuppliers = new MetroFramework.Controls.MetroTabPage();
            this.tabEmployees = new MetroFramework.Controls.MetroTabPage();
            this.tabReports = new MetroFramework.Controls.MetroTabPage();
            this.tabStock = new MetroFramework.Controls.MetroTabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnDashboard = new Telerik.WinControls.UI.RadButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnNew = new System.Windows.Forms.ToolStripButton();
            this.btnEdit = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtSearch = new System.Windows.Forms.ToolStripTextBox();
            this.btnSearch = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.statusStrip.SuspendLayout();
            this.panel1.SuspendLayout();
            this.metroTabControl1.SuspendLayout();
            this.tabSales.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnDashboard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.BackColor = System.Drawing.SystemColors.Control;
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(20, 489);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(847, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.metroTabControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(20, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(847, 40);
            this.panel1.TabIndex = 4;
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.metroTabControl1.Controls.Add(this.tabSales);
            this.metroTabControl1.Controls.Add(this.tabItems);
            this.metroTabControl1.Controls.Add(this.tabCustomers);
            this.metroTabControl1.Controls.Add(this.tabSuppliers);
            this.metroTabControl1.Controls.Add(this.tabEmployees);
            this.metroTabControl1.Controls.Add(this.tabReports);
            this.metroTabControl1.Controls.Add(this.tabStock);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.FontWeight = MetroFramework.MetroTabControlWeight.Bold;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Multiline = true;
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(847, 40);
            this.metroTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.metroTabControl1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroTabControl1.TabIndex = 7;
            this.metroTabControl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTabControl1.UseSelectable = true;
            // 
            // tabSales
            // 
            this.tabSales.Controls.Add(this.metroPanel4);
            this.tabSales.HorizontalScrollbarBarColor = true;
            this.tabSales.HorizontalScrollbarHighlightOnWheel = false;
            this.tabSales.HorizontalScrollbarSize = 10;
            this.tabSales.Location = new System.Drawing.Point(4, 41);
            this.tabSales.Name = "tabSales";
            this.tabSales.Size = new System.Drawing.Size(839, 0);
            this.tabSales.TabIndex = 0;
            this.tabSales.Tag = "IC";
            this.tabSales.Text = "SALES";
            this.tabSales.VerticalScrollbarBarColor = true;
            this.tabSales.VerticalScrollbarHighlightOnWheel = false;
            this.tabSales.VerticalScrollbarSize = 10;
            // 
            // metroPanel4
            // 
            this.metroPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(0, 0);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(839, 10);
            this.metroPanel4.TabIndex = 2;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // tabItems
            // 
            this.tabItems.BackColor = System.Drawing.Color.White;
            this.tabItems.Location = new System.Drawing.Point(4, 41);
            this.tabItems.Name = "tabItems";
            this.tabItems.Size = new System.Drawing.Size(839, -5);
            this.tabItems.TabIndex = 7;
            this.tabItems.Text = "ITEMS";
            // 
            // tabCustomers
            // 
            this.tabCustomers.HorizontalScrollbarBarColor = true;
            this.tabCustomers.HorizontalScrollbarHighlightOnWheel = false;
            this.tabCustomers.HorizontalScrollbarSize = 10;
            this.tabCustomers.Location = new System.Drawing.Point(4, 41);
            this.tabCustomers.Name = "tabCustomers";
            this.tabCustomers.Size = new System.Drawing.Size(839, -5);
            this.tabCustomers.TabIndex = 1;
            this.tabCustomers.Text = "CUSTOMERS";
            this.tabCustomers.VerticalScrollbarBarColor = true;
            this.tabCustomers.VerticalScrollbarHighlightOnWheel = false;
            this.tabCustomers.VerticalScrollbarSize = 10;
            // 
            // tabSuppliers
            // 
            this.tabSuppliers.HorizontalScrollbarBarColor = true;
            this.tabSuppliers.HorizontalScrollbarHighlightOnWheel = false;
            this.tabSuppliers.HorizontalScrollbarSize = 10;
            this.tabSuppliers.Location = new System.Drawing.Point(4, 41);
            this.tabSuppliers.Name = "tabSuppliers";
            this.tabSuppliers.Size = new System.Drawing.Size(839, -5);
            this.tabSuppliers.TabIndex = 2;
            this.tabSuppliers.Text = "SUPPLIERS";
            this.tabSuppliers.VerticalScrollbarBarColor = true;
            this.tabSuppliers.VerticalScrollbarHighlightOnWheel = false;
            this.tabSuppliers.VerticalScrollbarSize = 10;
            // 
            // tabEmployees
            // 
            this.tabEmployees.HorizontalScrollbarBarColor = true;
            this.tabEmployees.HorizontalScrollbarHighlightOnWheel = false;
            this.tabEmployees.HorizontalScrollbarSize = 10;
            this.tabEmployees.Location = new System.Drawing.Point(4, 41);
            this.tabEmployees.Name = "tabEmployees";
            this.tabEmployees.Size = new System.Drawing.Size(839, -5);
            this.tabEmployees.TabIndex = 3;
            this.tabEmployees.Text = "EMPLOYEES";
            this.tabEmployees.VerticalScrollbarBarColor = true;
            this.tabEmployees.VerticalScrollbarHighlightOnWheel = false;
            this.tabEmployees.VerticalScrollbarSize = 10;
            // 
            // tabReports
            // 
            this.tabReports.HorizontalScrollbarBarColor = true;
            this.tabReports.HorizontalScrollbarHighlightOnWheel = false;
            this.tabReports.HorizontalScrollbarSize = 10;
            this.tabReports.Location = new System.Drawing.Point(4, 41);
            this.tabReports.Name = "tabReports";
            this.tabReports.Size = new System.Drawing.Size(839, -5);
            this.tabReports.TabIndex = 4;
            this.tabReports.Text = "REPORTS";
            this.tabReports.VerticalScrollbarBarColor = true;
            this.tabReports.VerticalScrollbarHighlightOnWheel = false;
            this.tabReports.VerticalScrollbarSize = 10;
            // 
            // tabStock
            // 
            this.tabStock.HorizontalScrollbarBarColor = true;
            this.tabStock.HorizontalScrollbarHighlightOnWheel = false;
            this.tabStock.HorizontalScrollbarSize = 10;
            this.tabStock.Location = new System.Drawing.Point(4, 41);
            this.tabStock.Name = "tabStock";
            this.tabStock.Size = new System.Drawing.Size(839, -5);
            this.tabStock.TabIndex = 5;
            this.tabStock.Text = "STOCKROOM";
            this.tabStock.VerticalScrollbarBarColor = true;
            this.tabStock.VerticalScrollbarHighlightOnWheel = false;
            this.tabStock.VerticalScrollbarSize = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.bindingNavigator1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(20, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(847, 50);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(20, 150);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(128, 339);
            this.panel3.TabIndex = 6;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnDashboard, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.69182F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.30817F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(128, 339);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btnDashboard
            // 
            this.btnDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnDashboard.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Location = new System.Drawing.Point(3, 3);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(122, 28);
            this.btnDashboard.TabIndex = 0;
            this.btnDashboard.Text = "DASHBOARD";
            this.btnDashboard.TextWrap = true;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // btnNew
            // 
            this.btnNew.Image = ((System.Drawing.Image)(resources.GetObject("btnNew.Image")));
            this.btnNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(51, 36);
            this.btnNew.Text = "New";
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Image = ((System.Drawing.Image)(resources.GetObject("btnEdit.Image")));
            this.btnEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(47, 36);
            this.btnEdit.Text = "Edit";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(60, 36);
            this.toolStripButton1.Text = "Delete";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem,
            this.eXportToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(68, 36);
            this.toolStripSplitButton1.Text = "Tools";
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.importToolStripMenuItem.Text = "Import";
            // 
            // eXportToolStripMenuItem
            // 
            this.eXportToolStripMenuItem.Name = "eXportToolStripMenuItem";
            this.eXportToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.eXportToolStripMenuItem.Text = "Export";
            // 
            // txtSearch
            // 
            this.txtSearch.AutoSize = false;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(300, 39);
            // 
            // btnSearch
            // 
            this.btnSearch.Image = global::Kaunda.Properties.Resources.Ampeross_Qetto_2_Search;
            this.btnSearch.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(62, 36);
            this.btnSearch.Text = "Search";
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.BackColor = System.Drawing.SystemColors.Control;
            this.bindingNavigator1.CountItem = null;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorSeparator2,
            this.btnNew,
            this.btnEdit,
            this.toolStripButton1,
            this.toolStripSplitButton1,
            this.txtSearch,
            this.btnSearch});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 11);
            this.bindingNavigator1.MoveFirstItem = null;
            this.bindingNavigator1.MoveLastItem = null;
            this.bindingNavigator1.MoveNextItem = null;
            this.bindingNavigator1.MovePreviousItem = null;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = null;
            this.bindingNavigator1.Size = new System.Drawing.Size(847, 39);
            this.bindingNavigator1.TabIndex = 3;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // MDIParent1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 531);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip);
            this.IsMdiContainer = true;
            this.Name = "MDIParent1";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Style = MetroFramework.MetroColorStyle.Default;
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.metroTabControl1.ResumeLayout(false);
            this.tabSales.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnDashboard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage tabSales;
        private MetroFramework.Controls.MetroPanel metroPanel4;
        private System.Windows.Forms.TabPage tabItems;
        private MetroFramework.Controls.MetroTabPage tabCustomers;
        private MetroFramework.Controls.MetroTabPage tabSuppliers;
        private MetroFramework.Controls.MetroTabPage tabEmployees;
        private MetroFramework.Controls.MetroTabPage tabReports;
        private MetroFramework.Controls.MetroTabPage tabStock;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Telerik.WinControls.UI.RadButton btnDashboard;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton btnNew;
        private System.Windows.Forms.ToolStripButton btnEdit;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXportToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox txtSearch;
        private System.Windows.Forms.ToolStripButton btnSearch;
    }
}



