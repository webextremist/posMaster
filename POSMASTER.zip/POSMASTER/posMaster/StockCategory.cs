﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kaunda;

namespace Kaunda
{
 public   class StockCategory
    {
     private string _description;
     private string _loginUser;
        public string Description 
        { 
            get
            {
            return _description.ToUpper();
            
            }

            set
            {
                _description = value;
            }
        
        }
        public string LoginUser 
        {
            get
            {
                return _loginUser.ToLower();
            }

            set
            {
                _loginUser = value;
            
            }
        
        }
    }

}
