﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kaunda;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
namespace Kaunda
{
  public  class Records
    {
      DataTable dt = new DataTable();
      MySqlDataAdapter da = new MySqlDataAdapter();
   //   string Query;
    }

    
//    public DataTable SELECT()
//{

//    return 1;
//}

    
}
