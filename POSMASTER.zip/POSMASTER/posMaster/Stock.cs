﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaunda
{
  public  class Stock
    {

        //        IN paraItemID int
        //,       IN paraQuantity int
        //,       IN paraUnitPrice decimal(18,2)
        //,       IN paraMakerID   int
        //,       IN paraMfgDate date
        //,       IN paraExpDate date
        //,       IN paraBatchNo varchar(50)
        //,       IN paraStatus char(1)
        //,       IN paraLoginUser varchar(50)


        //SELECT Stock_name,Unit_Price,make_id,mfgDate,expDate ,category_id,batch_no, loginUser FROM stock s;
        public int          ItemID                      { get; set; }
        public string       Quantity                    { get; set; }
        public double       UnitPrice                   { get; set; }
        public int          MakeID                      { get; set; }
        public DateTime       ManufactureDate             { get; set; }
        public DateTime       ExpirationDate              { get; set; }
        public string       BatchNo                     { get; set; }
        public string       StockStatus                 { get; set; }


    }
}
