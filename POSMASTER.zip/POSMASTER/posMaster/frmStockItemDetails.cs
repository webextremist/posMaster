﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace Kaunda
{
    public partial class frmStockItemDetails : MetroForm
    {
        int count;
        DataCenter datacenter = new DataCenter();

        public frmStockItemDetails()
        {
            InitializeComponent();
        }

        private void frmStockItemDetails_Load(object sender, EventArgs e)
        {

            cmbCategory.DisplayMember = "categoryname";
            cmbCategory.ValueMember = "categoryid";
            cmbCategory.DataSource = datacenter.SELECT("call getCategory(1)");

            cmbItems.DisplayMember = "itemname";
            cmbItems.ValueMember = "itemid";
            cmbItems.DataSource = datacenter.SELECT("CALL getItems(1)");
           // cmbItems.DataSource = datacenter.SELECT("CALL getItemByCategoryID('" + cmbCategoryStockTab.SelectedValue + "')");

            cmbMaker.DisplayMember = "make";
            cmbMaker.ValueMember = "makeid";
            cmbMaker.DataSource = datacenter.SELECT("CALL getItemMake(1)");

            cmbCategoryStockTab.DisplayMember = "categoryname";
            cmbCategoryStockTab.ValueMember = "categoryid";
            cmbCategoryStockTab.DataSource = datacenter.SELECT("call getCategory(1)");

            dgvCategory.DataSource = datacenter.SELECT("CALL getCategory(1)"); // loop not in use yet
           // dgvItems.DataSource = datacenter.SELECT("CALL CALL getItemByCategoryID('" + cmbCategory.SelectedValue  + "')");
            for (int i = 0; i < this.dgvCategory.Columns.Count; i++)
            {
               
                this.dgvStock.MasterTemplate.Columns["NAME"].Width=400;
                this.dgvCategory.MasterTemplate.Columns["categoryname"].Width = 500;
                this.dgvItems.MasterTemplate.Columns["itemname"].Width = 600;
                this.dgvStock.MasterTemplate.Columns["itemid"].IsVisible = false;
                this.dgvStock.MasterTemplate.Columns["categoryid"].IsVisible = false;
                
                //this.dgvCategory.Mastertemplate.Columns[i].MinWidth = ;
                //this.dgvCategory.MasterGridViewTemplate.Columns[i].MaxWidth = 60;
                //this.dgvCategory.MasterGridViewTemplate.Columns[i].Width = 60;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            StockCategory category = new StockCategory();
            category.Description = txtName.Text;
 
           count= datacenter.AddCategory(category);

           if (count > 0)
           {
               MessageBox.Show(string.Concat(txtName .Text .ToUpper() ,Environment.NewLine," is added to categories"));
               dgvCategory.DataSource = datacenter.SELECT("CALL getCategory(1)");
           }
           else
           {
               MessageBox.Show("oops!!");
           }

        }



        private void btnAddCategoroyItem_Click(object sender, EventArgs e)
        {
            Item item = new Item();
            item.ItemName = txtItemName.Text;
            item.CategoryID = int.Parse( cmbCategory.SelectedValue.ToString());

          count =   datacenter.AddItem(item);
          if (count > 0)
          {

              MessageBox.Show (string.Concat(txtItemName.Text," is added") );
              dgvItems.DataSource = datacenter.SELECT("CALL getItemByCategoryID('" + cmbCategory.SelectedValue + "')");
          }
          else
          {
              MessageBox.Show("Could not save data");
          }


        }

        private void btnAddStock_Click(object sender, EventArgs e)
        {
            
            //        IN paraItemID int
 //,       IN paraQuantity int
 //,       IN paraUnitPrice decimal(18,2)
 //,       IN paraMakerID   int
 //,       IN paraMfgDate date
 //,       IN paraExpDate date
 //,       IN paraBatchNo varchar(50)
 //,       IN paraStatus char(1)
 //,       IN paraLoginUser varchar(50)
            
            Stock stock = new Stock();
            stock.ItemID = int.Parse(cmbItems.SelectedValue.ToString());
            stock.Quantity = txtQuantity.Text;
            stock.MakeID = int.Parse(cmbMaker.SelectedValue.ToString());
            stock.ManufactureDate =  dtpMfgDate.Value;
            stock.ExpirationDate = dtpExpDate.Value;
            stock.BatchNo = txtBatchNo.Text;

            count = datacenter.AddStock(stock);
            if (count > 0)
            {
                MessageBox.Show(string.Concat(txtQuantity.Text, " is added !"));
                dgvStock.DataSource = datacenter.SELECT("CALL getItemsStock('" + cmbCategoryStockTab.SelectedValue + "')");
            }

            else
            {
                MessageBox.Show("oops");
            }

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvItems.DataSource = datacenter.SELECT("CALL getItemByCategoryID('" + cmbCategory.SelectedValue + "')");
        }

        private void cmbCategoryStockTab_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvStock.DataSource = datacenter.SELECT("CALL getItemsStock('" + cmbCategoryStockTab.SelectedValue + "')");

            cmbItems.DisplayMember = "itemname";
            cmbItems.ValueMember = "itemid";
            cmbItems.DataSource = datacenter.SELECT("CALL getItemByCategoryID('" + cmbCategoryStockTab.SelectedValue + "')");

        }

        private void cmbItems_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radPageView1_SelectedPageChanging(object sender, Telerik.WinControls.UI.RadPageViewCancelEventArgs e)
        {
            if (radPageView1.SelectedPage == radPageView1.Pages["tabCategory"])
            {
                cmbCategory.DisplayMember = "categoryname";
                cmbCategory.ValueMember = "categoryid";
                cmbCategory.DataSource = datacenter.SELECT("call getCategory(1)");
            }
            else if (radPageView1.SelectedPage == radPageView1.Pages["tabItems"])
            {
                cmbItems.DisplayMember = "itemname";
                cmbItems.ValueMember = "itemid";
                cmbItems.DataSource = datacenter.SELECT("CALL getItems(1)");
                // cmbItems.DataSource = datacenter.SELECT("CALL getItemByCategoryID('" + cmbCategoryStockTab.SelectedValue + "')");

            }

            else if (radPageView1.SelectedPage == radPageView1.Pages["tabStock"])
            { 
            
            }
        }



    }
}
