﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaunda
{
  static  class Global
    {

      private static string _username="Kaunda";

      public static string Username
      {

          get
          {
              return _username.ToLower();
          }

          set
          {
              _username = value;
          }
      }

    }
}
