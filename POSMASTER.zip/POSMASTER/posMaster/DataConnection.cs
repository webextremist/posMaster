﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaunda
{
    class DataConnection
    {
        public int MyProperty { get; set; }
    }
}
