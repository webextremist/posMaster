﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
namespace Kaunda
{
    public partial class frmSales : MetroForm
    {
        DataCenter data = new DataCenter();
        public frmSales()
        {
            InitializeComponent();
        }

        private void frmPOS_Load(object sender, EventArgs e)
        {
            cmbStockCategory.DisplayMember = "CATEGORY_ID";
            cmbStockCategory.ValueMember = "DESCRIPTION";
            cmbStockCategory.DataSource = data.SELECT("SELECT CATEGORY_ID,DESCRIPTION FROM STOCK_CATEGORY");

                
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
