﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace Kaunda
{
    public partial class Form1 : MetroForm
    {
        // FORM LEVEL VARIABLES
        Stock stock = new Stock();
        DataCenter datacenter = new DataCenter();
        int count;


    //    MySqlConnection Connect2DB = new MySqlConnection("Server=localhost;Database=stock;Uid=root;Pwd=Khan@2015");

        public Form1()
        {
            InitializeComponent();
        }

// get Records

       

        public  DataTable getRecords(string Qry)
        {
            DataTable myDataTable = new DataTable();
            MySqlDataAdapter myDataAdapter = new MySqlDataAdapter(Qry, DataAccess.Connection);
            myDataAdapter.Fill(myDataTable);

            return myDataTable;
        }


        private void Form1_Load(object sender, EventArgs e)
        {

            try
            {
                //MySqlConnection con = new MySqlConnection(Properties.Settings.Default.Connect2DB);
                //MySqlDataAdapter dapter = new MySqlDataAdapter("select * from itemdetails", con);
                //DataTable dt = new DataTable();

                //dapter.Fill(dt);

              //  DisplayItems.DataSource = getRecords("SELECT * FROM activitylog a;");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {

        }

        private void splitPanel1_Click(object sender, EventArgs e)
        {

        }



        //private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (metroTabControl1.SelectedTab == metroTabControl1.TabPages["tabItems"])
        //    {
        //        DisplayItems.DataSource = getRecords("SELECT * FROM activitylog a;");

        //    }

        //}



        private void btnNew_Click(object sender, EventArgs e)
        {
            if (metroTabControl1.SelectedTab == metroTabControl1.TabPages["tabItems"])
            { 
               frmAddNewItem frm = new frmAddNewItem();
               //frm.MdiParent = this;
               frm.ShowDialog();
            }
            else if (metroTabControl1.SelectedTab == metroTabControl1.TabPages["tabPOS"])
            {
                frmSales frm = new frmSales();
              //  frm.MdiParent = this;
             //   frm.ShowDialog();
            }
           
        }

        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
              if (metroTabControl1.SelectedTab == metroTabControl1.TabPages["tabItems"])
              {
               //   DisplayItems.DataSource = getRecords("SELECT * FROM activitylog a;");

              }
              else if (metroTabControl1.SelectedTab == metroTabControl1.TabPages[""])
              {
               //  DisplayItems.DataSource = getRecords("SELECT * FROM select * from staff s;");
              }
              else {

                  if (DisplayItems.DataSource != null)
                  {
                   DisplayItems.DataSource = null; 
                  }
                 
              
              }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //button1.Text = dateTimePicker1.Value.ToShortDateString();

            //return;
 //           stock.StockID = 0;


//            CREATE DEFINER=`khan`@`localhost` PROCEDURE `AddStock`(
//          IN stockID                    int
//,         IN Stack_Name                 varchar(250)
//,         IN Unit_Price                 decimal(18,2)
//,         IN Product_Maker              int
//,         IN Manufactured_Date          date
//,         IN Expiration_Date            date
//,         IN Product_Category           int
//,         IN Batch_Number               varchar(45)
//,         IN LoginUser                  varchar(45)

//)


            //DateTime dt = new DateTime ();
            //dt = dateTimePicker1.Value.Date;

            //if (DateTime .TryParse (dateTimePicker1 .Text  ,out dt))
            //{
            

            //}
            //string str = dateTimePicker1 .Text   ;
            //DateTime dd = dateTimePicker1.Value .Date ;
            //button1.Text = DateTime .Parse (dateTimePicker1 .Value .Date .ToString ("dd/mm/yy")).ToString ();
            //return;

            //stock.ITEM ="Terrible Connection Error entery";
            //stock.UnitPrice = 10;
            //stock.Maker = 1;
            //stock.ManufactureDate = dateTimePicker1.Value.ToString();
            //stock.ExpirationDate = dateTimePicker1.Value.ToString();
            //stock.Category = 1;
            //stock.BatchNumber = "BAT0012980";
            //stock.LoginUser = "kaunda";

            count = datacenter.AddStock(stock);

            if (count > 0)
            {
                MessageBox.Show("OK");
               
            }
            else
            { 
            MessageBox .Show ("KO");
            }
        }
    }
}