﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kaunda
{
   public class Item
    {

       private string _itemname;
      // private string _categoryid;

       public string ItemName { 
           get
               
           {
           return _itemname;
           } set
           {
           _itemname=value.ToUpper();
           } }


       public int CategoryID { get; set; }

   }

}





