﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient ;
using Kaunda;
using System.Configuration;
using System.Data;
namespace Kaunda
{
  public static   class DataAccess
    {
      static MySqlConnection varcon = new MySqlConnection(Properties .Settings .Default .Connect2DB );

      public static MySqlConnection Connection 
      {

          get { return varcon;
          }
      
      }

      public static void OpenConnection()
      {
          varcon.ConnectionString = ConfigurationManager.ConnectionStrings["Connect2DB"].ConnectionString;

          if (Connection.State != System.Data.ConnectionState.Open)
          { 
           varcon .Open();
          }
         

      }

      public static void CloseConnection()
      {
      varcon.Close ();
      }



      // SELECT DATA

    }
}
