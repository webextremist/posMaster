﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using MySql.Data.MySqlClient;
using Kaunda;

namespace Kaunda
{
   public class DataCenter
    {
    
       MySqlDataAdapter Adapter ;//= new MySqlDataAdapter ();
      // DataSet myDataset ;//= new DataSet();
       DataTable dt;// = new DataTable();

       int Count;

       public void InitializeProcedure(string ProcedureName)
       {
           MySqlCommand mycommand = new MySqlCommand();
           mycommand.CommandType = CommandType.StoredProcedure;
           mycommand.CommandText = ProcedureName;
           mycommand.Connection = DataAccess.Connection;

           DataAccess.OpenConnection();
       }


       // ADD STOCK
       public int AddStock(Stock stock)
       {
           MySqlCommand mycommand = new MySqlCommand();
           mycommand.CommandType = CommandType.StoredProcedure;
           mycommand.CommandText = "AddStock";
           mycommand.Connection = DataAccess.Connection;

           DataAccess.OpenConnection();

           
 //          CREATE DEFINER=`root`@`localhost` PROCEDURE `AddStock`(
 //        IN paraItemID int
 //,       IN paraQuantity int
 //,       IN paraUnitPrice decimal(18,2)
 //,       IN paraMakerID   int
 //,       IN paraMfgDate date
 //,       IN paraExpDate date
 //,       IN paraBatchNo varchar(50)
 //,       IN paraStatus char(1)
 //,       IN paraLoginUser varchar(50)
      
           var myvar = mycommand.Parameters;

          // myvar.Add("stockID", MySqlDbType.VarChar).Value = stock.StockID ;
           myvar.AddWithValue("paraItemID", stock.ItemID);
           myvar.AddWithValue("paraQuantity", stock.Quantity);
           myvar.AddWithValue("paraUnitPrice",stock.UnitPrice) ;
           myvar.AddWithValue("paraMakerID",stock.MakeID);
           myvar.AddWithValue("paraMfgDate", stock.ManufactureDate);
           myvar.AddWithValue("paraExpDate", stock.ExpirationDate);
           myvar.AddWithValue("paraBatchNo", stock.BatchNo);
           myvar.AddWithValue("paraLoginUser", Global.Username);
           
           Count = mycommand.ExecuteNonQuery();
           DataAccess.CloseConnection();

           return Count;
       }

       public int UpdateStock(Stock stock)
       {
          
           // NO CODE YET
           return Count;
       }
       
       public DataTable SELECT(String Query)
       {
           dt = new DataTable();
           Adapter = new MySqlDataAdapter(Query, DataAccess.Connection);
           Adapter.Fill(dt);

           return dt;
       }
     
       // ADD  CATEGORY
       public int  AddCategory(StockCategory category)
       {
           MySqlCommand mycom = new MySqlCommand("AddCategory", DataAccess.Connection);
           mycom.CommandType = CommandType.StoredProcedure;

           DataAccess.OpenConnection();
        //   SetCommandProcedure("AddCategory");
           var p = mycom.Parameters;
           p.AddWithValue("paraCategoryName", category.Description);
           p.AddWithValue("paraLoginUser", Global.Username);
         
          Count = mycom.ExecuteNonQuery();
        
          
           DataAccess.CloseConnection();
           return Count;
       }

       public int AddItem(Item item)
       {

           MySqlCommand mycom = new MySqlCommand("AddItem", DataAccess.Connection);
           mycom.CommandType = CommandType.StoredProcedure;

           DataAccess.OpenConnection();
           var p = mycom.Parameters;

//           CREATE DEFINER=`root`@`localhost` PROCEDURE `AddItem`(
//          in paraItemName varchar(250)
//          ,in paraCategoryID int
//          ,in paraloginuser varchar(32)

           p.AddWithValue("paraItemName", item.ItemName);
           p.AddWithValue("paraCategoryID", item.CategoryID);
           p.AddWithValue("paraloginuser", Global.Username);
           Count = mycom.ExecuteNonQuery();

           DataAccess.CloseConnection();
           return Count;
       }

       public void SetCommandProcedure(string ProcedureName)
       {
           MySqlCommand mycom = new MySqlCommand(ProcedureName, DataAccess.Connection);
           mycom.CommandType = CommandType.StoredProcedure;

           DataAccess.OpenConnection();

       }

       public int AddMake(Make make)
       { 
       
//           create procedure AddMake
//(
//    paraMake varchar(250)
//  , paraloginUser varchar(32)
           MySqlCommand mycom = new MySqlCommand("AddMake", DataAccess.Connection);
           mycom.CommandType = CommandType.StoredProcedure;

           DataAccess.OpenConnection();
           var p = mycom.Parameters;

           p.AddWithValue("paraMake", make.ManufacturerName.ToUpper());
           p.AddWithValue("paraloginUser", Global.Username);

           Count = mycom.ExecuteNonQuery();
           return Count;
       }
        
    }
}
